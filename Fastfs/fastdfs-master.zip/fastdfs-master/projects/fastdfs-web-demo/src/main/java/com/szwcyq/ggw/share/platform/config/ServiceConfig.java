/*package com.szwcyq.ggw.share.platform.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ServiceConfig{

}
*/