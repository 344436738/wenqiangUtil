/**
 * 封装与服务端交易命令
 * 
 * @author tobato
 *
 */
package com.szwcyq.ggw.share.fastdfs.proto;