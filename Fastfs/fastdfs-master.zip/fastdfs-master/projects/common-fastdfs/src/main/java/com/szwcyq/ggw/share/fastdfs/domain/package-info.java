/**
 * FDFS领域对象
 * 
 * @author tobato
 *
 */
package com.szwcyq.ggw.share.fastdfs.domain;