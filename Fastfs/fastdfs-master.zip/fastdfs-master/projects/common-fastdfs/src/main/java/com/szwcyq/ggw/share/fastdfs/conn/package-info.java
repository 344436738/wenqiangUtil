/**
 * 连接管理
 * 通信管理
 * 业务逻辑不应该关心连接、通信的细节
 * 
 * @author tobato
 *
 */
package com.szwcyq.ggw.share.fastdfs.conn;